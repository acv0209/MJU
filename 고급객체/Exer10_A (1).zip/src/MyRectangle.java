import java.awt.Point;
import java.awt.Rectangle;

public class MyRectangle extends MyShape {
	
	public MyRectangle() {
		super(new Rectangle());
	}

	@Override
	public void setCoordinate(Point currentP) {
		Rectangle rectangle = (Rectangle)shape;
		rectangle.setFrame(startP.x, startP.y, currentP.x - startP.x, 
				currentP.y - startP.y);
	}

	@Override
	public MyShape clone() {
		return new MyRectangle();
	}

}
