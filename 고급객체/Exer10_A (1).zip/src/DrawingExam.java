import java.awt.BorderLayout;

import javax.swing.JFrame;

public class DrawingExam extends JFrame {
	private ShapesPanel sp;
	private DrawingPanel dp;
	
	public DrawingExam() {
		super("Drawing Exam");
		
		sp = new ShapesPanel();
		dp = new DrawingPanel();
		
		sp.init(dp);
		
		this.add(sp, BorderLayout.NORTH);
		this.add(dp, BorderLayout.CENTER);
		
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(600, 400);
		this.setVisible(true);
	}
	public static void main(String[] args) {
		new DrawingExam();
	}

}
