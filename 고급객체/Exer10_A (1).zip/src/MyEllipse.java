import java.awt.Point;
import java.awt.geom.Ellipse2D;

public class MyEllipse extends MyShape {
	
	public MyEllipse(){
		super(new Ellipse2D.Double());
	}

	@Override
	public void setCoordinate(Point currentP) {
		Ellipse2D ellipse = (Ellipse2D)shape;
		ellipse.setFrame(startP.x, startP.y, 
				currentP.x - startP.x, currentP.y - startP.y);
	}

	@Override
	public MyShape clone() {
		return new MyEllipse();
	}

}
