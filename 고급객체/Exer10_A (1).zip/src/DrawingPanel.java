import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JPanel;

public class DrawingPanel extends JPanel {
	private MyHandler handler;
	private MyShape currentShape;
	private List<MyShape> shapeList;///////////
	
	public DrawingPanel() {
		this.setBackground(Color.WHITE);
		handler = new MyHandler();
		shapeList = new ArrayList<>();/////////////
		
		this.addMouseListener(handler);
		this.addMouseMotionListener(handler);
	}
	
	public void setCurrentShape(MyShape currentShape) {
		this.currentShape = currentShape;
	}

	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2D = (Graphics2D)g;
		for(MyShape shape : shapeList) {
			shape.draw(g2D);
		}
	}

	private class MyHandler extends MouseAdapter{

		@Override
		public void mouseDragged(MouseEvent e) {
			Graphics2D g2D = (Graphics2D)getGraphics();
			g2D.setXORMode(g2D.getBackground());
			currentShape.draw(g2D);
			currentShape.setCoordinate(e.getPoint());
			currentShape.draw(g2D);
		}

		@Override
		public void mousePressed(MouseEvent e) {
			currentShape = currentShape.clone();
			currentShape.initDraw(e.getPoint());
		}

		@Override
		public void mouseReleased(MouseEvent e) {
			shapeList.add(currentShape);
		}
		
	}
}






