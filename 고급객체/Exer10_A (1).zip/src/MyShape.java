import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Shape;

public abstract class MyShape {
	protected Shape shape;
	protected Point startP;
	
	public MyShape(Shape shape) {
		this.shape = shape;
	}
	
	public void initDraw(Point startP) {
		this.startP = startP;
	}
	
	public void draw(Graphics2D g2D) {
		g2D.draw(shape);
	}
	
	public abstract void setCoordinate(Point currentP);
	public abstract MyShape clone();
	
}








