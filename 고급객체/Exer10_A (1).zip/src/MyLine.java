import java.awt.Point;
import java.awt.geom.Line2D;

public class MyLine extends MyShape {
	
	public MyLine() {
		super(new Line2D.Double());
	}

	@Override
	public void setCoordinate(Point currentP) {
		Line2D line = (Line2D)shape;
		line.setLine(startP.x, startP.y, currentP.x, currentP.y);
	}

	@Override
	public MyShape clone() {
		return new MyLine();
	}

}
