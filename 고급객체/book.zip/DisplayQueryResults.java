package book;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.SQLException;
import java.util.regex.PatternSyntaxException;
import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.swing.ScrollPaneConstants;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

public class DisplayQueryResults extends JFrame {
	static final String DATABASE_URL = 
			"jdbc:mysql://localhost:3306/books?characterEncoding=UTF-8&serverTimezone=UTC";
	static final String USERNAME = "root";
	static final String PASSWORD = "pass";
	
	static final String DEFAULT_QUERY = "SELECT * FROM Authors";
	
	private ResultSetTableModel tableModel;
	private JTextArea queryArea;
	
	public DisplayQueryResults() {
		super("Dispalying QueryResults");
		
		try {
			tableModel = 
				new ResultSetTableModel(DATABASE_URL, USERNAME, PASSWORD, DEFAULT_QUERY);
			
			queryArea = new JTextArea(DEFAULT_QUERY, 3, 100);
			queryArea.setWrapStyleWord(true);
			queryArea.setLineWrap(true);
			
			JScrollPane scrollPane = new JScrollPane(queryArea,
					ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
					ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
			
			JButton submitButton = new JButton("Submit Query");
			
			Box boxNorth = Box.createHorizontalBox();
			boxNorth.add(scrollPane);
			boxNorth.add(submitButton);
			
			JTable resultTable = new JTable(tableModel);
			
			JLabel filterLabel = new JLabel("Filter:");
			final JTextField filterText = new JTextField();
			JButton filterButton = new JButton("Apply Filter");
			Box boxSouth = Box.createHorizontalBox();
			
			boxSouth.add(filterLabel);
			boxSouth.add(filterText);
			boxSouth.add(filterButton);
			
			this.add(boxNorth, BorderLayout.NORTH);
			this.add(new JScrollPane(resultTable), BorderLayout.CENTER);
			this.add(boxSouth, BorderLayout.SOUTH);
			
			submitButton.addActionListener(
				new ActionListener() {
					public void actionPerformed(ActionEvent event) {
						try {
							tableModel.setQuery(queryArea.getText());
						}catch(SQLException sqlException) {
							JOptionPane.showMessageDialog(null, sqlException.getMessage(), 
									"Database error", JOptionPane.ERROR_MESSAGE);
							try {
								tableModel.setQuery(DEFAULT_QUERY);
								queryArea.setText(DEFAULT_QUERY);
							}catch(SQLException sqlException2) {
								JOptionPane.showMessageDialog(null, sqlException2.getMessage(),
										"Database error", JOptionPane.ERROR_MESSAGE);
								tableModel.disconnectedFromDatabase();
								
								System.exit(1);
							}
						}
					}
				}
			);
			
			final TableRowSorter<TableModel> sorter = new TableRowSorter<TableModel>(tableModel);
			resultTable.setRowSorter(sorter);
			this.setSize(500, 250);
			this.setVisible(true);
			
			filterButton.addActionListener(
				new ActionListener() {
					public void actionPerformed(ActionEvent event) {
						String text = filterText.getText();
						
						if(text.length() == 0) {
							sorter.setRowFilter(null);
						}else {
							try {
								sorter.setRowFilter(RowFilter.regexFilter(text));
							}catch(PatternSyntaxException pse) {
								JOptionPane.showMessageDialog(null, "Bad regex pattern", 
										"Bad regex pattern", JOptionPane.ERROR_MESSAGE);
							}
						}
					}
				}
			);
		}catch(SQLException sqlException) {
			JOptionPane.showMessageDialog(null,  sqlException.getMessage(),	
					"Database error", JOptionPane.ERROR_MESSAGE);
			tableModel.disconnectedFromDatabase();
			System.exit(1);
		}
		
		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		
		this.addWindowListener(
			new WindowAdapter() {
				public void windowClosed(WindowEvent event) {
					tableModel.disconnectedFromDatabase();
					System.exit(0);
				}
			}
		);
	}
	
	public static void main(String[] args) {
		new DisplayQueryResults();
	}
}
