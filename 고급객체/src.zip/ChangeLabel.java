import java.awt.Color;
import java.awt.Container;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class ChangeLabel extends JFrame {

	private JLabel la;

	public ChangeLabel(){
		super("ChangeLabel");		
		setLayout(null);
		
		for(int y = 0; y < 6; y++){
			for(int x = 0; x < 10; x++){
				la = new JLabel("HELLO");
				la.setSize(60, 30);//JLabel�� ũ�� ����
				la.addMouseListener(new MyHandler()); //�̺�Ʈ ������ ���
				la.setLocation(x*60, y*30); //JLabel�� ��ġ ����
				add(la);
			}			
		}
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(300, 180);
		this.setVisible(true);
	}

	private class MyHandler extends MouseAdapter{

		@Override
		public void mouseEntered(MouseEvent e) {
			JLabel label = (JLabel)e.getSource();
			label.setText("JAVA");
			label.setForeground(Color.MAGENTA);
		}
		@Override
		public void mouseExited(MouseEvent e) {
			JLabel label = (JLabel)e.getSource();
			label.setText("HELLO");
			label.setForeground(Color.BLACK);
		}

	}
	public static void main(String[] args) {
		new ChangeLabel();
	}

}