package calculator;

public abstract class Calculator {
	int num1, num2;
	
	abstract int calc(int num1, int num2);
	
	abstract void prtResult();
}
