package calculator;

public class AddCalculator extends Calculator{
	
	public AddCalculator(int num1, int num2) {
		this.num1 = num1;
		this.num2 = num2;
	}

	void prtResult() {
		int result = calc(num1, num2);
		System.out.println("�������� " + result + " �Դϴ�.");
	}

	@Override
	int calc(int num1, int num2) {
		return num1 + num2;
	}
	
	public static void main(String[] args) {
	
		Calculator calc = new AddCalculator(10, 20);
		
		calc.prtResult();
	
	}
}
