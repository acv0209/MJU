import java.awt.BorderLayout;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextArea;

public class Calculator extends JFrame {
	
	private JButton btn;
	private JTextArea ta;
	private String btnCom[] = {"7", "8", "9", "/", 
								"4", "5", "6", "*", 
								"1", "2", "3", "-",
								"0", ".", "=", "+"};
	
	public Calculator(){

		super("Calculator");
		
		JPanel jp = new JPanel();
		jp.setLayout(new GridLayout(4, 4, 5, 5));
		
		for(String cmt : btnCom){
			btn = new JButton(cmt);
			btn.setActionCommand(cmt);
			btn.addActionListener(e -> ta.append(e.getActionCommand()));
			jp.add(btn);
		}
		
		ta = new JTextArea(1, 20);
		
		this.add(ta, BorderLayout.NORTH);
		this.add(jp, BorderLayout.CENTER);

		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.pack();
		this.setVisible(true);		
	}

	public static void main(String args[]){
		new Calculator();
	}
}
