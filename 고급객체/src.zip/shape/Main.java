package shape;

public class Main {

	public static void main(String[] args) {
		
		Shape[] list = {new Circle(10), 
				new Oval(20, 30), 
				new Rect(10, 40)
		};
		
		for (Shape s : list) {
			s.redraw();
			System.out.printf("������ %.2f\n", s.getArea());
		}
	}

}
