package shape;

public interface Shape {
	double PI = 3.14;
	void draw();
	
	double getArea();
	
	default public void redraw() {
		System.out.print("--- �ٽ� �׸��ϴ�. ");
		draw();
	}
}
