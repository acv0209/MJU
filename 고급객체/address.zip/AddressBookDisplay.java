package address;

import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class AddressBookDisplay extends JFrame {

	private Person currentEntry;
	private PersonQueries personQueries;
	private List<Person> results;
	private int numberOfEntries = 0;
	private int currentEntryIndex;

	private JButton browseButton;
	private JTextField emailTextField;
	private JTextField firstNameTextField;
	private JTextField idTextField;
	private JTextField indexTextField;
	private JTextField lastNameTextField;
	private JTextField maxTextField;
	private JButton nextButton;
	private JTextField phoneTextField;
	private JButton previousButton;
	private JButton queryButton;
	private JTextField queryTextField;
	private JButton insertButton;

	public AddressBookDisplay() {
		super("Address Book");

		personQueries = new PersonQueries();

		JPanel navigatePanel = new JPanel();
		JPanel queryPanel = new JPanel();
		JPanel displayPanel = new JPanel();

		previousButton = new JButton("Previous");
		indexTextField = new JTextField(2);
		maxTextField = new JTextField(2);
		nextButton = new JButton("Next");
		idTextField = new JTextField(10);
		firstNameTextField = new JTextField(10);
		lastNameTextField = new JTextField(10);
		emailTextField = new JTextField(10);
		phoneTextField = new JTextField(10);
		queryTextField = new JTextField(10);
		queryButton = new JButton("Find");
		browseButton = new JButton("Browse All Entires");
		insertButton = new JButton("Insert New Entry");

		this.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 10));
		this.setSize(400, 300);
		this.setResizable(false);

		navigatePanel.setLayout(new BoxLayout(navigatePanel, BoxLayout.X_AXIS));

		previousButton.setEnabled(false);
		previousButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent evt) {
				previousButtonActionForformed(evt);

			}

		});

		navigatePanel.add(previousButton);
		navigatePanel.add(Box.createHorizontalStrut(10));

		indexTextField.setHorizontalAlignment(JTextField.CENTER);
		indexTextField.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent evt) {
				indexTextFieldActionPerformed(evt);
			}

		});

		navigatePanel.add(indexTextField);
		navigatePanel.add(Box.createHorizontalStrut(10));

		navigatePanel.add(new JLabel("of"));
		navigatePanel.add(Box.createHorizontalStrut(10));

		maxTextField.setHorizontalAlignment(JTextField.CENTER);
		maxTextField.setEditable(false);
		navigatePanel.add(maxTextField);
		navigatePanel.add(Box.createHorizontalStrut(10));

		nextButton.setEnabled(false);
		nextButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent evt) {
				nextButtonActionPerformed(evt);

			}

		});

		navigatePanel.add(nextButton);
		this.add(navigatePanel);

		displayPanel.setLayout(new GridLayout(5, 2, 4, 4));
		displayPanel.add(new JLabel("Address ID:"));

		idTextField.setEnabled(false);
		displayPanel.add(idTextField);

		displayPanel.add(new JLabel("First Name:"));
		displayPanel.add(firstNameTextField);

		displayPanel.add(new JLabel("Last Name:"));
		displayPanel.add(lastNameTextField);

		displayPanel.add(new JLabel("Email:"));
		displayPanel.add(emailTextField);

		displayPanel.add(new JLabel("Phone Number:"));
		displayPanel.add(phoneTextField);

		this.add(displayPanel);

		queryPanel.setLayout(new BoxLayout(queryPanel, BoxLayout.X_AXIS));
		queryPanel.setBorder(BorderFactory.createTitledBorder("Find an entry by last name"));
		queryPanel.add(Box.createHorizontalStrut(5));
		queryPanel.add(new JLabel("Last Name:"));
		queryPanel.add(Box.createHorizontalStrut(10));
		queryPanel.add(queryTextField);
		queryPanel.add(Box.createHorizontalStrut(10));

		queryButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent evt) {
				querButtonActionPerformed(evt);
			}

		});

		queryPanel.add(queryButton);
		queryPanel.add(Box.createHorizontalStrut(5));
		this.add(queryPanel);

		browseButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent evt) {
				browseButtonActionPerformed(evt);
			}

		});

		this.add(browseButton);

		insertButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent evt) {
				insertButtonActonPerformed(evt);
			}

		});

		this.add(insertButton);

		this.addWindowListener(new WindowAdapter() {

			@Override
			public void windowClosing(WindowEvent evt) {
				personQueries.close();
				System.exit(0);
			}
		});

		this.setVisible(true);
	}

	private void previousButtonActionForformed(ActionEvent evt) {
		currentEntryIndex--;

		if(currentEntryIndex < 0) {
			currentEntryIndex = numberOfEntries - 1;
		}

		indexTextField.setText("" + (currentEntryIndex + 1));
		indexTextFieldActionPerformed(evt);
	}

	private void indexTextFieldActionPerformed(ActionEvent evt) {
		currentEntryIndex = (Integer.parseInt(indexTextField.getText()) - 1);

		if(numberOfEntries != 0 && currentEntryIndex < numberOfEntries) {
			currentEntry = results.get(currentEntryIndex);
			idTextField.setText("" + currentEntry.getAddressID());
			firstNameTextField.setText(currentEntry.getFirstName());
			lastNameTextField.setText(currentEntry.getLastName());
			emailTextField.setText(currentEntry.getEmail());
			phoneTextField.setText(currentEntry.getPhoneNumber());
			maxTextField.setText("" + numberOfEntries);
			indexTextField.setText("" + (currentEntryIndex + 1));
		}
	}

	private void nextButtonActionPerformed(ActionEvent evt) {
		currentEntryIndex++;

		if(currentEntryIndex >= numberOfEntries) {
			currentEntryIndex = 0;
		}

		indexTextField.setText("" + (currentEntryIndex + 1));
		indexTextFieldActionPerformed(evt);
	}

	private void querButtonActionPerformed(ActionEvent evt) {
		results = personQueries.getPeopleByLastName(queryTextField.getText());
		numberOfEntries = results.size();
		if(numberOfEntries != 0) {
			currentEntryIndex = 0;
			currentEntry = results.get(currentEntryIndex);
			idTextField.setText("" + currentEntry.getAddressID());
			firstNameTextField.setText(currentEntry.getFirstName());
			lastNameTextField.setText(currentEntry.getLastName());
			emailTextField.setText(currentEntry.getEmail());
			phoneTextField.setText(currentEntry.getPhoneNumber());
			maxTextField.setText("" + numberOfEntries);
			indexTextField.setText("" + (currentEntryIndex + 1));
			nextButton.setEnabled(true);
			previousButton.setEnabled(true);
		}else {
			browseButtonActionPerformed(evt);
		}
	}

	private void browseButtonActionPerformed(ActionEvent evt) {
		try {
			results = personQueries.getAllPeople();
			numberOfEntries = results.size();

			if(numberOfEntries != 0) {
				currentEntryIndex = 0;
				currentEntry = results.get(currentEntryIndex);
				idTextField.setText("" + currentEntry.getAddressID());
				firstNameTextField.setText(currentEntry.getFirstName());
				lastNameTextField.setText(currentEntry.getLastName());
				emailTextField.setText(currentEntry.getEmail());
				phoneTextField.setText(currentEntry.getPhoneNumber());
				maxTextField.setText("" + numberOfEntries);
				indexTextField.setText("" + (currentEntryIndex + 1));
				nextButton.setEnabled(true);
				previousButton.setEnabled(true);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

	private void insertButtonActonPerformed(ActionEvent evt) {
		int result = personQueries.addPerson(firstNameTextField.getText(), 
				lastNameTextField.getText(), emailTextField.getText(), phoneTextField.getText());

		if(result == 1) {
			JOptionPane.showMessageDialog(this, "Person Added!", "Person Added", JOptionPane.PLAIN_MESSAGE);
		}else {
			JOptionPane.showMessageDialog(this, "Person not added!", "Error", JOptionPane.PLAIN_MESSAGE);
		}

		browseButtonActionPerformed(evt);
	}

	public static void main(String[] args) {
		new AddressBookDisplay();
	}

}
