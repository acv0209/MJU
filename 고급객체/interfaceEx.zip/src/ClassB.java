
public class ClassB implements B {

	@Override
	public void method1() {
		System.out.println("ClassB's method1");
	}

	@Override
	public void method2() {
		System.out.println("ClassB's method2");
	}

}
