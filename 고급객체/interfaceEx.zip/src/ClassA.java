
public class ClassA implements A {

	@Override
	public void method1() {
		System.out.println("ClassA's method1");
	}

}
