
public interface B extends A {
	void method2();
}
