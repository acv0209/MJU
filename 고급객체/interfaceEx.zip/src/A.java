public interface A {
	void method1();
	default void method3() {
		System.out.println("A's method3");
	}
}
