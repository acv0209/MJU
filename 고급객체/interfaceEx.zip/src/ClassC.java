
public class ClassC implements A {

	@Override
	public void method1() {
		System.out.println("ClassC's method1");
	}

}
