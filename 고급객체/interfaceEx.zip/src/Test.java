
public class Test {

	public static void main(String[] args) {
		ClassA obja = new ClassA();
		//obja.method1();
		A a = obja;
		a.method1();
		ClassB objb = new ClassB();
		a = objb;
		a.method1();
		B b = (B)a;
		b.method2();
		ClassC objc = new ClassC();
		a = objc;
		a.method1();
		a.method3();
		

	}

}
