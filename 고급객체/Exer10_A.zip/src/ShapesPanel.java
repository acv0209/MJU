import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

public class ShapesPanel extends JPanel {
	private MyHandler handler;
	private DrawingPanel dp;
	
	public ShapesPanel() {
		handler = new MyHandler();
		String btNames[] = {"Line", "Rectangle", "Ellipse"};
		JRadioButton rb;
		ButtonGroup bg = new ButtonGroup();
		for(String btn : btNames) {
			rb = new JRadioButton(btn);
			rb.setActionCommand(btn);
			rb.addActionListener(handler);
			this.add(rb);
			bg.add(rb);
		}
	}
	
	public void init(DrawingPanel dp) {
		this.dp = dp;
		defaultClick();
	}
	
	private void defaultClick() {
		JRadioButton rButton = (JRadioButton)this.getComponent(1);
		rButton.doClick();
	}

	private class MyHandler implements ActionListener{

		@Override
		public void actionPerformed(ActionEvent e) {
			String shapeType = e.getActionCommand();
			
			switch(shapeType) {
			case "Line":
				dp.setCurrentShape(null);
				break;
			case "Rectangle":
				dp.setCurrentShape(new MyRectangle());
				break;
			case "Ellipse":
				dp.setCurrentShape(null);
				break;
			}
			
		}
		
	}

}







