import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JPanel;

public class DrawingPanel extends JPanel {
	private MyHandler handler;
	private MyShape currentShape;
	
	public DrawingPanel() {
		this.setBackground(Color.WHITE);
		handler = new MyHandler();
		
		this.addMouseListener(handler);
		this.addMouseMotionListener(handler);
	}
	
	public void setCurrentShape(MyShape currentShape) {
		this.currentShape = currentShape;
	}


	private class MyHandler extends MouseAdapter{

		@Override
		public void mouseDragged(MouseEvent e) {
			
		}

		@Override
		public void mousePressed(MouseEvent e) {
			
		}

		@Override
		public void mouseReleased(MouseEvent e) {
			
		}
		
	}
}






